<?php

namespace App\Entities;

use CodeIgniter\Entity;

class WargaEntity extends Entity
{
	
}
