<?php

namespace App\Entities;

use CodeIgniter\Entity;

class BookEntity extends Entity
{
}
