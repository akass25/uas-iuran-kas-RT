<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2022-07-07 00:01:32 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 00:31:18 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 01:01:25 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 01:31:30 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 02:01:23 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 02:31:24 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 02:34:36 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 02:34:36 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 02:34:37 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 02:34:38 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 03:01:22 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 03:08:37 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 03:08:37 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 03:08:39 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 03:08:40 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 03:31:28 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 04:01:20 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 04:31:23 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 05:01:28 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 05:31:20 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 06:01:33 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 06:31:28 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 06:37:10 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-07 06:39:30 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
