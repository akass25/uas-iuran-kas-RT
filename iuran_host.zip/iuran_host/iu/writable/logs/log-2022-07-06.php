<?php defined('SYSTEMPATH') || exit('No direct script access allowed'); ?>

CRITICAL - 2022-07-06 09:45:13 --> Unable to connect to the database.
Main connection [MySQLi]: Access denied for user ''@'localhost' (using password: NO)
#0 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Database\BaseConnection.php(625): CodeIgniter\Database\BaseConnection->initialize()
#1 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Database\BaseBuilder.php(1981): CodeIgniter\Database\BaseConnection->query('SELECT COUNT(*)...', Array, false)
#2 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Model.php(561): CodeIgniter\Database\BaseBuilder->countAllResults(true)
#3 C:\xampp\htdocs\iuran_kas\app\Controllers\Home.php(15): CodeIgniter\Model->countAllResults()
#4 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\CodeIgniter.php(928): App\Controllers\Home->index()
#5 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\CodeIgniter.php(436): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Home))
#6 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\CodeIgniter.php(336): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\iuran_kas\public\index.php(44): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Commands\Server\rewrite.php(45): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2022-07-06 09:45:16 --> Unable to connect to the database.
Main connection [MySQLi]: Access denied for user ''@'localhost' (using password: NO)
#0 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Database\BaseConnection.php(625): CodeIgniter\Database\BaseConnection->initialize()
#1 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Database\BaseBuilder.php(1981): CodeIgniter\Database\BaseConnection->query('SELECT COUNT(*)...', Array, false)
#2 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Model.php(561): CodeIgniter\Database\BaseBuilder->countAllResults(true)
#3 C:\xampp\htdocs\iuran_kas\app\Controllers\Home.php(15): CodeIgniter\Model->countAllResults()
#4 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\CodeIgniter.php(928): App\Controllers\Home->index()
#5 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\CodeIgniter.php(436): CodeIgniter\CodeIgniter->runController(Object(App\Controllers\Home))
#6 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\CodeIgniter.php(336): CodeIgniter\CodeIgniter->handleRequest(NULL, Object(Config\Cache), false)
#7 C:\xampp\htdocs\iuran_kas\public\index.php(44): CodeIgniter\CodeIgniter->run()
#8 C:\xampp\htdocs\iuran_kas\vendor\codeigniter4\framework\system\Commands\Server\rewrite.php(45): require_once('C:\\xampp\\htdocs...')
#9 {main}
CRITICAL - 2022-07-06 16:51:02 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:51:10 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:51:10 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:51:17 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:51:29 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:51:32 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:51:49 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:51:54 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:52:32 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:52:35 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:53:00 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:53:02 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:53:03 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:53:54 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 16:58:06 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 17:02:02 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 17:15:05 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 17:31:25 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 17:47:05 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 18:01:30 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 18:25:17 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 18:31:26 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 19:01:19 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 19:31:27 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 20:01:21 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 20:31:38 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 21:01:15 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 21:31:22 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 22:01:15 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 22:31:15 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 23:01:18 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 23:15:09 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 23:17:05 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
CRITICAL - 2022-07-06 23:31:14 --> Call to undefined function CodeIgniter\locale_set_default()
#0 /home/u1597167/public_html/xxz/iu/vendor/codeigniter4/framework/system/bootstrap.php(157): CodeIgniter\CodeIgniter->initialize()
#1 /home/u1597167/public_html/xxz/iu/public/index.php(35): require('/home/u1597167/...')
#2 {main}
